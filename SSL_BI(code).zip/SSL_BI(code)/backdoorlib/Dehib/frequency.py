import kornia
from scipy.fftpack import dct, idct
from skimage import color

def DCT(img):
    return dct(dct(img.T, norm='ortho').T, norm='ortho')

def IDCT(img):
    return idct(idct(img.T, norm='ortho').T, norm='ortho')

def RGB2YUV(x_rgb):
    # return kornia.color.rgb_to_yuv(x_rgb)
    return color.rgb2yuv(x_rgb)

def YUV2RGB(x_yuv):
    # return kornia.color.yuv_to_rgb(x_yuv)
    return color.yuv2rgb(x_yuv)