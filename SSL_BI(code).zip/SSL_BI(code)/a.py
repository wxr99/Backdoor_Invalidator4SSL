import torch
x = torch.tensor([1.0,2.0,3.0], requires_grad=True).cuda(0)
x[1]=2*x[1]
y = x*x
z= 2*y
y.retain_grad()
loss = y.clone().mean()
loss.retain_grad()
loss.backward()
print(y.grad)